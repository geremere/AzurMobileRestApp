# Azure Cosmos DB SQL API Xamarin Getting Started Changelog

<a name="1.0.0"></a>
# 1.0.0 (2018-05-30)

## Features

* Initial Release
* Xamarin.Forms app with Azure Cosmos DB SQL API integration

## Bug Fixes

* None

## Breaking Changes

* None