﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ср
{
    public delegate bool Eq(Circle e);

    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo k;
            do
            {
                Random rnd = new Random();
                Circle[] cr = new Circle[15];
                for (int i = 0; i < 15; i++)
                {
                    cr[i] = new Circle(rnd.Next(-11, 9) + rnd.NextDouble(), rnd.Next(0, 7) + rnd.NextDouble());
                    Console.WriteLine(cr[i].ToString());
                }
                double s=0;
                IRead(s);
                int crore = 0;
                Console.WriteLine($"Circle S >{s}:\n");
                for (int i = 0; i < cr.Length; i++)
                {
                    if (cr[i].R * cr[i].R * Math.PI > s)
                    {
                        Console.WriteLine(cr[i].ToString());
                        crore++;
                    }
                }
                Console.WriteLine($"Количество {crore}");


                Console.WriteLine("To exit escape");
                k = Console.ReadKey(true);
            } while (k.Key != ConsoleKey.Escape);
        }

        private static void IRead(double s)
        {
            try
            {
                s = double.Parse(Console.ReadLine());
            }
            catch (Exception e)
            {            
                Console.WriteLine(e.Message);
                IRead(s);
            }
        }
    }
}
