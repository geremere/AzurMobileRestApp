﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace tets2.Views
{
    public partial class MyPage : ContentPage
    {
        public MyPage()
        {
            InitializeComponent();
        }
    }
}
